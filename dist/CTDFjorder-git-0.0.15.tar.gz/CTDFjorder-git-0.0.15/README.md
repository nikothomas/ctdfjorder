# CTDFjorder

CTDFjorder is a Python package for processing and analyzing CTD (Conductivity, Temperature, Depth) data.
Documentation: [Read the docs](https://nikothomas.github.io/CTDFjorder/CTDFjorder/CTDFjorder.html)

## Features

- Read RSK files and extract CTD data
- Process CTD data, including removing non-positive samples and cleaning data
- Calculate derived quantities such as absolute salinity, density, and overturns
- Determine mixed layer depth (MLD) using different methods
- Generate plots for visualizing CTD profiles and derived quantities
- Command-line interface (CLI) for easy processing and merging of RSK files

## Installation

To install CTDFjorder, you can use pip:

```shell
pip install ctdfjorder
```

## Usage

CTDFjorder provides a command-line interface (CLI) for processing and analyzing CTD data. Here are the available commands:

### Process a single RSK file

```shell
ctdfjorder-cli process <file>
```

This command processes a single RSK file specified by `<file>`. It performs various steps like adding filename to the CTD data table, saving data to a CSV file, adding location information, removing non-positive samples, etc.

### Merge all RSK files in the current folder

```shell
ctdfjorder-cli merge
```

This command merges all RSK files found in the current folder. It adds filename and location information to the data table and saves the data to a CSV file.

### Run the default processing pipeline

```shell
ctdfjorder-cli default
```

This command runs the default processing pipeline on all RSK files found in the current folder. It performs the same steps as the `process` command for each RSK file.

## Configuration

CTDFjorder looks for a master sheet Excel file named "FjordPhyto MASTER SHEET.xlsx" in the current working directory. This file is used for estimating location information when it's not available in the RSK files. You can change this by modifying the CTDFjorder.master_sheet_path field to the name of your own spreadsheet.

## Examples

Here are a few examples of how to use CTDFjorder:

- Process a single RSK file:

```shell
ctdfjorder-cli process path/to/rskfile.rsk
```

- Merge all RSK files in the current folder:

```shell
ctdfjorder-cli merge
```

- Run the default processing pipeline on all RSK files in the current folder:

```shell
ctdfjorder-cli default
```

- Write your own script:
```
from CTDFjorder import CTDFjorder
import os
for file in CTDFjorder.get_rsk_filenames_in_dir(os.getcwd()):
    try:
        my_data = CTDFjorder.CTD(file)
        my_data.add_filename_to_table()
        my_data.save_to_csv("output.csv")
        my_data.add_location_to_table()
        my_data.remove_non_positive_samples()
        my_data.clean("practicalsalinity", 'salinitydiff')
        my_data.add_absolute_salinity()
        my_data.add_density()
        my_data.add_overturns()
        my_data.add_mld(1)
        my_data.add_mld(5)
        my_data.save_to_csv("outputclean.csv")
        my_data.plot_depth_density_salinity_mld_scatter()
        my_data.plot_depth_temperature_scatter()
        my_data.plot_depth_salinity_density_mld_line()
    except Exception as e:
        print(f"Error processing file: '{file}' {e}")
        continue
```

## Contributing

Contributions to CTDFjorder are welcome! If you find any issues or have suggestions for improvements, please open an issue or submit a pull request on the [GitHub repository](https://github.com).

## License

CTDFjorder is released under the MIT License.

## Acknowledgments

CTDFjorder was developed by Nikolas Yanek-Chrones for the Fjord Phyto project. The gsw library was used for certain dervied calculations.

## Citations
McDougall, T. J., & Barker, P. M. (2011). Getting started with TEOS-10 and the Gibbs Seawater (GSW) Oceanographic Toolbox. SCOR/IAPSO WG127.

